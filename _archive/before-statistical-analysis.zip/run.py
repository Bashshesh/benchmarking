from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'networkx_repo'
COMMITS = [
    '87b57851e9e55b91d8471960fef9b4ca4c373837',
    '6da4704cbf32ba6f50f6d9c46cc0a071e3a87985',
]


def main():
    # Клонирование нужно только при первом запуске.
    if not REPO.exists():
        subprocess.run(['git', 'clone', 'https://github.com/networkx/networkx.git',
                        str(REPO)], check=True)

    # Не переключаем версию, если кто-то редактировал скачанный NetworkX.
    changes = subprocess.check_output(
        ['git', 'status', '--porcelain'], cwd=REPO, text=True)
    if changes.strip():
        raise RuntimeError('В networkx_repo есть изменения. Сначала сохрани их отдельно.')

    # Проверяем обе версии до начала измерений.
    for commit in COMMITS:
        subprocess.run(['git', 'rev-parse', '--verify', commit + '^{commit}'],
                       cwd=REPO, check=True, stdout=subprocess.DEVNULL)

    # Новый запуск заменяет таблицу предыдущего запуска.
    (ROOT / 'results.csv').write_text('commit,repeat,seconds\n', encoding='utf-8')
    env = os.environ.copy()
    env['PYTHONHASHSEED'] = '0'
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    for commit in COMMITS:
        print(f'\nNetworkX: {commit[:10]}', flush=True)
        subprocess.run(['git', 'checkout', '--detach', commit], cwd=REPO, check=True)
        # Отдельный Python-процесс: в памяти не останется импорт старой версии.
        subprocess.run([sys.executable, '-B', str(ROOT / 'benchmark.py'), commit],
                       env=env, check=True)

    subprocess.run([sys.executable, str(ROOT / 'analyze.py')], check=True)


if __name__ == '__main__':
    main()
