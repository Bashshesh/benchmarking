import csv
from pathlib import Path
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'networkx_repo'))
import networkx as nx

REPEATS = 20    
LOOPS = 100 
WARMUPS = 3


def main():
    commit = sys.argv[1]
    if not Path(nx.__file__).resolve().is_relative_to(ROOT / 'networkx_repo'):
        raise RuntimeError('Импортирована неправильная копия NetworkX')

    graph = nx.grid_2d_graph(35, 35)
    for _ in range(WARMUPS):
        nx.single_source_shortest_path_length(graph, (0, 0))

    with (ROOT / 'results.csv').open('a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        for repeat in range(1, REPEATS + 1):
            start = perf_counter()  # НАЧАЛО измеряемого участка.
            for _ in range(LOOPS):
                distances = nx.single_source_shortest_path_length(graph, (0, 0))
            elapsed = perf_counter() - start  # КОНЕЦ измеряемого участка.

            # Проверка результата и запись CSV находятся за пределами таймера.
            assert len(distances) == 1225 and distances[(34, 34)] == 68
            seconds = elapsed / LOOPS  # Среднее время одного вызова в этой пачке.
            writer.writerow([commit, repeat, seconds])
            print(f'  Измерение {repeat:2}: {seconds * 1000:.3f} ms', flush=True)


if __name__ == '__main__':
    main()
