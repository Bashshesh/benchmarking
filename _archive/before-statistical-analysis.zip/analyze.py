import csv
from pathlib import Path
from statistics import mean, stdev

ROOT = Path(__file__).resolve().parent
THRESHOLD = 5  


def main():
    measurements = {}
    with (ROOT / 'results.csv').open(newline='', encoding='utf-8') as file:
        for row in csv.DictReader(file):
            measurements.setdefault(row['commit'], []).append(float(row['seconds']))

    if len(measurements) != 2 or any(len(values) < 2 for values in measurements.values()):
        raise ValueError('Нужны две версии и минимум два измерения каждой. Запусти run.py.')
    sizes = [len(values) for values in measurements.values()]
    if sizes[0] != sizes[1]:
        raise ValueError('Число измерений различается: возможно, запуск прервался.')

    print('\nРЕЗУЛЬТАТЫ (время одного вызова)')
    averages = []
    for commit, values in measurements.items():
        average = mean(values)
        averages.append(average)
        print(f'{commit[:10]}: n={len(values)}, mean={average * 1000:.3f} ms, '
              f'SD={stdev(values) * 1000:.3f} ms')

    old, new = averages 
    change = (new - old) / old * 100
    print(f'Изменение среднего: {change:+.2f}%')
    if change > THRESHOLD:
        print(f'Возможное замедление больше {THRESHOLD}%. Нужно проверить повторным экспериментом.')
    elif change < -THRESHOLD:
        print(f'Возможное ускорение больше {THRESHOLD}%. Нужно проверить повторным экспериментом.')
    else:
        print(f'Изменение среднего находится в пределах ±{THRESHOLD}%.')
    print('Это сравнение средних, НЕ проверка статистической значимости.')


if __name__ == '__main__':
    main()
